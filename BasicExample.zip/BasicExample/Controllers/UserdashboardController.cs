﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
using System.Data;
namespace BasicExample.Controllers
{
    public class UserdashboardController : Controller
    {
        //
        // GET: /Userdashboard/
        Database1Entities db = new Database1Entities();
      
        public ActionResult Index()
        {
            if (TempData["key"] == null)
            {
                return RedirectToAction("Index", "Login");
            }
            var s = db.Registrations.Find(TempData["key"].ToString());
            TempData.Keep();
            return View(s);
        }

        public ActionResult Editprofile(String id)
        {
           
            var s = db.Registrations.Find(id);
            return View(s);
        }

        [HttpPost]
        public ActionResult Editprofile(Registration r)
        {
            db.Entry(r).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Deleteprofile(String id)
        {
            var s = db.Registrations.Find(id);
            db.Registrations.Remove(s);
            db.SaveChanges();

            return RedirectToAction("Index","Login");
        }

        public ActionResult Logout(String id)
        {

            TempData.Remove("key");

            return RedirectToAction("Index", "Login");
        }

    }
}
