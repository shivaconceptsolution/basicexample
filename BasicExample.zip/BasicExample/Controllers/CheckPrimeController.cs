﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BasicExample.Controllers
{
    public class CheckPrimeController : Controller
    {
        //
        // GET: /CheckPrime/

        public ActionResult Index(int id1)
        {
            int i;
            for (i = 2; i < id1; i++)
            {
                if (id1 % i == 0)
                {
                    ViewBag.data = "NOT Prime";
                    break;
                }
            }
            if (id1 == i)
            {
                ViewBag.data = "Prime";
            }
            return View();
        }

    }
}
