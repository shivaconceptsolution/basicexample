﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BasicExample.Controllers
{
    public class ActionResultExampleController : Controller
    {
        //
        // GET: /ActionResultExample/

       
        public ViewResult Index1()
        {
            return View();
        }
        public ContentResult Index2()
        {
            return Content("Hello World");
        }
        public EmptyResult Index3()
        {
            ViewBag.data = "Empty Result";
            Response.Write(ViewBag.data);
            return new EmptyResult();
        }
        public PartialViewResult Index4()
        {
            return PartialView();
        }

        public FileResult Index5()
        {
            return new FilePathResult("~\\App_Data\\SEO-SITE.txt", "text/plain");
           // return File(Path.Combine("~/App_Data",Server.MapPath("SEO-SITE.txt")), "text/plain");
        }

        public JsonResult Index6()
        {
            return Json(new {Name="scs",ID=101},JsonRequestBehavior.AllowGet);
        }
        public JavaScriptResult Index7()
        {
            return JavaScript("alert('welcome in JS')");
        }

        public RedirectToRouteResult Index8()
        {
            //return RedirectPermanent("https://shivaconceptdigital.com");
           // return RedirectToRoute(new { controller = "Table", action = "Index" });
            return RedirectToRoute("MyRoute");
        }

    }
}
