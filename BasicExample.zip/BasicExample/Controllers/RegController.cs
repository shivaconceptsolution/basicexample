﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
namespace BasicExample.Controllers
{
    public class RegController : Controller
    {
        Database1Entities db = new Database1Entities();
        //
        // GET: /Reg/

        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Registration r)
        {
            db.Registrations.Add(r);
            db.SaveChanges();
            ViewBag.data = "Registration Successfully";
            return View();
        }

    }
}
