﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasicExample.Models
{
    public class TableModel
    {
        public int num {get;set;}

    }
}