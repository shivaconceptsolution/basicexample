﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasicExample.Models
{
    public class Enquiry
    {
        public int EnqId { get; set; }
        public String FirstName { get; set; }
        public String MobileNo { get; set; }
        public String Gender { get; set; }
        public String CourseName { get; set; }

    }
}